﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        MenuStrip1 = New MenuStrip()
        ArchivoToolStripMenuItem = New ToolStripMenuItem()
        NuevoToolStripMenuItem = New ToolStripMenuItem()
        NuevaVentanaToolStripMenuItem = New ToolStripMenuItem()
        AbrirToolStripMenuItem = New ToolStripMenuItem()
        GuardarToolStripMenuItem = New ToolStripMenuItem()
        GuardarToolStripMenuItem1 = New ToolStripMenuItem()
        ConfiguraciónDePaginaToolStripMenuItem = New ToolStripMenuItem()
        ImprimirToolStripMenuItem = New ToolStripMenuItem()
        SalirToolStripMenuItem = New ToolStripMenuItem()
        EdiciónToolStripMenuItem = New ToolStripMenuItem()
        DeshacerToolStripMenuItem = New ToolStripMenuItem()
        CortarToolStripMenuItem = New ToolStripMenuItem()
        CopiarToolStripMenuItem = New ToolStripMenuItem()
        PegarToolStripMenuItem = New ToolStripMenuItem()
        EliminarToolStripMenuItem = New ToolStripMenuItem()
        BuscarToolStripMenuItem = New ToolStripMenuItem()
        BuscarSiguienteToolStripMenuItem = New ToolStripMenuItem()
        ReemplazarToolStripMenuItem = New ToolStripMenuItem()
        IrAToolStripMenuItem = New ToolStripMenuItem()
        SeleccionarTodoToolStripMenuItem = New ToolStripMenuItem()
        FuenteToolStripMenuItem = New ToolStripMenuItem()
        VerToolStripMenuItem = New ToolStripMenuItem()
        ZoomToolStripMenuItem = New ToolStripMenuItem()
        AcercarToolStripMenuItem = New ToolStripMenuItem()
        AlejarToolStripMenuItem = New ToolStripMenuItem()
        RestaurarZoomPredeterminadoToolStripMenuItem = New ToolStripMenuItem()
        BarraDeEstadoToolStripMenuItem = New ToolStripMenuItem()
        AjusteDeLíneaToolStripMenuItem = New ToolStripMenuItem()
        AyudaToolStripMenuItem = New ToolStripMenuItem()
        VerLaAyudaToolStripMenuItem = New ToolStripMenuItem()
        EnviarComentariosToolStripMenuItem = New ToolStripMenuItem()
        AcercaDelBlocDeNotasToolStripMenuItem = New ToolStripMenuItem()
        BúsquedaConBingToolStripMenuItem = New ToolStripMenuItem()
        BuscarAnteriorToolStripMenuItem = New ToolStripMenuItem()
        FormatoToolStripMenuItem = New ToolStripMenuItem()
        AjusteDeLíneaToolStripMenuItem1 = New ToolStripMenuItem()
        FuenteToolStripMenuItem1 = New ToolStripMenuItem()
        MenuStrip1.SuspendLayout()
        SuspendLayout()
        ' 
        ' MenuStrip1
        ' 
        MenuStrip1.ImageScalingSize = New Size(20, 20)
        MenuStrip1.Items.AddRange(New ToolStripItem() {ArchivoToolStripMenuItem, EdiciónToolStripMenuItem, FormatoToolStripMenuItem, VerToolStripMenuItem, AyudaToolStripMenuItem})
        MenuStrip1.Location = New Point(0, 0)
        MenuStrip1.Name = "MenuStrip1"
        MenuStrip1.Size = New Size(800, 28)
        MenuStrip1.TabIndex = 0
        MenuStrip1.Text = "MenuStrip1"
        ' 
        ' ArchivoToolStripMenuItem
        ' 
        ArchivoToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {NuevoToolStripMenuItem, NuevaVentanaToolStripMenuItem, AbrirToolStripMenuItem, GuardarToolStripMenuItem, GuardarToolStripMenuItem1, ConfiguraciónDePaginaToolStripMenuItem, ImprimirToolStripMenuItem, SalirToolStripMenuItem})
        ArchivoToolStripMenuItem.Name = "ArchivoToolStripMenuItem"
        ArchivoToolStripMenuItem.Size = New Size(73, 24)
        ArchivoToolStripMenuItem.Text = "&Archivo"
        ' 
        ' NuevoToolStripMenuItem
        ' 
        NuevoToolStripMenuItem.Name = "NuevoToolStripMenuItem"
        NuevoToolStripMenuItem.Size = New Size(233, 26)
        NuevoToolStripMenuItem.Text = "Nuevo"
        ' 
        ' NuevaVentanaToolStripMenuItem
        ' 
        NuevaVentanaToolStripMenuItem.Name = "NuevaVentanaToolStripMenuItem"
        NuevaVentanaToolStripMenuItem.Size = New Size(233, 26)
        NuevaVentanaToolStripMenuItem.Text = "Nueva Ventana"
        ' 
        ' AbrirToolStripMenuItem
        ' 
        AbrirToolStripMenuItem.Name = "AbrirToolStripMenuItem"
        AbrirToolStripMenuItem.Size = New Size(233, 26)
        AbrirToolStripMenuItem.Text = "Abrir..."
        ' 
        ' GuardarToolStripMenuItem
        ' 
        GuardarToolStripMenuItem.Name = "GuardarToolStripMenuItem"
        GuardarToolStripMenuItem.Size = New Size(233, 26)
        GuardarToolStripMenuItem.Text = "Guardar"
        ' 
        ' GuardarToolStripMenuItem1
        ' 
        GuardarToolStripMenuItem1.Name = "GuardarToolStripMenuItem1"
        GuardarToolStripMenuItem1.Size = New Size(233, 26)
        GuardarToolStripMenuItem1.Text = "Guardar como..."
        ' 
        ' ConfiguraciónDePaginaToolStripMenuItem
        ' 
        ConfiguraciónDePaginaToolStripMenuItem.Name = "ConfiguraciónDePaginaToolStripMenuItem"
        ConfiguraciónDePaginaToolStripMenuItem.Size = New Size(242, 26)
        ConfiguraciónDePaginaToolStripMenuItem.Text = "Configurar de página..."
        ' 
        ' ImprimirToolStripMenuItem
        ' 
        ImprimirToolStripMenuItem.Name = "ImprimirToolStripMenuItem"
        ImprimirToolStripMenuItem.Size = New Size(242, 26)
        ImprimirToolStripMenuItem.Text = "Imprimir..."
        ' 
        ' SalirToolStripMenuItem
        ' 
        SalirToolStripMenuItem.Name = "SalirToolStripMenuItem"
        SalirToolStripMenuItem.Size = New Size(233, 26)
        SalirToolStripMenuItem.Text = "Salir"
        ' 
        ' EdiciónToolStripMenuItem
        ' 
        EdiciónToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {DeshacerToolStripMenuItem, CortarToolStripMenuItem, CopiarToolStripMenuItem, PegarToolStripMenuItem, EliminarToolStripMenuItem, BúsquedaConBingToolStripMenuItem, BuscarToolStripMenuItem, BuscarSiguienteToolStripMenuItem, BuscarAnteriorToolStripMenuItem, ReemplazarToolStripMenuItem, IrAToolStripMenuItem, SeleccionarTodoToolStripMenuItem, FuenteToolStripMenuItem})
        EdiciónToolStripMenuItem.Name = "EdiciónToolStripMenuItem"
        EdiciónToolStripMenuItem.Size = New Size(72, 24)
        EdiciónToolStripMenuItem.Text = "&Edición"
        ' 
        ' DeshacerToolStripMenuItem
        ' 
        DeshacerToolStripMenuItem.Name = "DeshacerToolStripMenuItem"
        DeshacerToolStripMenuItem.Size = New Size(224, 26)
        DeshacerToolStripMenuItem.Text = "Deshacer"
        ' 
        ' CortarToolStripMenuItem
        ' 
        CortarToolStripMenuItem.Name = "CortarToolStripMenuItem"
        CortarToolStripMenuItem.Size = New Size(224, 26)
        CortarToolStripMenuItem.Text = "Cortar"
        ' 
        ' CopiarToolStripMenuItem
        ' 
        CopiarToolStripMenuItem.Name = "CopiarToolStripMenuItem"
        CopiarToolStripMenuItem.Size = New Size(224, 26)
        CopiarToolStripMenuItem.Text = "Copiar"
        ' 
        ' PegarToolStripMenuItem
        ' 
        PegarToolStripMenuItem.Name = "PegarToolStripMenuItem"
        PegarToolStripMenuItem.Size = New Size(224, 26)
        PegarToolStripMenuItem.Text = "Pegar"
        ' 
        ' EliminarToolStripMenuItem
        ' 
        EliminarToolStripMenuItem.Name = "EliminarToolStripMenuItem"
        EliminarToolStripMenuItem.Size = New Size(224, 26)
        EliminarToolStripMenuItem.Text = "Eliminar"
        ' 
        ' BuscarToolStripMenuItem
        ' 
        BuscarToolStripMenuItem.Name = "BuscarToolStripMenuItem"
        BuscarToolStripMenuItem.Size = New Size(228, 26)
        BuscarToolStripMenuItem.Text = "Buscar..."
        ' 
        ' BuscarSiguienteToolStripMenuItem
        ' 
        BuscarSiguienteToolStripMenuItem.Name = "BuscarSiguienteToolStripMenuItem"
        BuscarSiguienteToolStripMenuItem.Size = New Size(224, 26)
        BuscarSiguienteToolStripMenuItem.Text = "Buscar siguiente"
        ' 
        ' ReemplazarToolStripMenuItem
        ' 
        ReemplazarToolStripMenuItem.Name = "ReemplazarToolStripMenuItem"
        ReemplazarToolStripMenuItem.Size = New Size(228, 26)
        ReemplazarToolStripMenuItem.Text = "Reemplazar..."
        ' 
        ' IrAToolStripMenuItem
        ' 
        IrAToolStripMenuItem.Name = "IrAToolStripMenuItem"
        IrAToolStripMenuItem.Size = New Size(228, 26)
        IrAToolStripMenuItem.Text = "Ir a..."
        ' 
        ' SeleccionarTodoToolStripMenuItem
        ' 
        SeleccionarTodoToolStripMenuItem.Name = "SeleccionarTodoToolStripMenuItem"
        SeleccionarTodoToolStripMenuItem.Size = New Size(224, 26)
        SeleccionarTodoToolStripMenuItem.Text = "Seleccionar todo"
        ' 
        ' FuenteToolStripMenuItem
        ' 
        FuenteToolStripMenuItem.Name = "FuenteToolStripMenuItem"
        FuenteToolStripMenuItem.Size = New Size(228, 26)
        FuenteToolStripMenuItem.Text = "Hora y Fecha"
        ' 
        ' VerToolStripMenuItem
        ' 
        VerToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {ZoomToolStripMenuItem, BarraDeEstadoToolStripMenuItem, AjusteDeLíneaToolStripMenuItem})
        VerToolStripMenuItem.Name = "VerToolStripMenuItem"
        VerToolStripMenuItem.Size = New Size(44, 24)
        VerToolStripMenuItem.Text = "&Ver"
        ' 
        ' ZoomToolStripMenuItem
        ' 
        ZoomToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {AcercarToolStripMenuItem, AlejarToolStripMenuItem, RestaurarZoomPredeterminadoToolStripMenuItem})
        ZoomToolStripMenuItem.Name = "ZoomToolStripMenuItem"
        ZoomToolStripMenuItem.Size = New Size(197, 26)
        ZoomToolStripMenuItem.Text = "Zoom"
        ' 
        ' AcercarToolStripMenuItem
        ' 
        AcercarToolStripMenuItem.Name = "AcercarToolStripMenuItem"
        AcercarToolStripMenuItem.Size = New Size(308, 26)
        AcercarToolStripMenuItem.Text = "Acercar"
        ' 
        ' AlejarToolStripMenuItem
        ' 
        AlejarToolStripMenuItem.Name = "AlejarToolStripMenuItem"
        AlejarToolStripMenuItem.Size = New Size(308, 26)
        AlejarToolStripMenuItem.Text = "Alejar"
        ' 
        ' RestaurarZoomPredeterminadoToolStripMenuItem
        ' 
        RestaurarZoomPredeterminadoToolStripMenuItem.Name = "RestaurarZoomPredeterminadoToolStripMenuItem"
        RestaurarZoomPredeterminadoToolStripMenuItem.Size = New Size(308, 26)
        RestaurarZoomPredeterminadoToolStripMenuItem.Text = "Restaurar zoom predeterminado"
        ' 
        ' BarraDeEstadoToolStripMenuItem
        ' 
        BarraDeEstadoToolStripMenuItem.Name = "BarraDeEstadoToolStripMenuItem"
        BarraDeEstadoToolStripMenuItem.Size = New Size(197, 26)
        BarraDeEstadoToolStripMenuItem.Text = "Barra de estado"
        ' 
        ' AjusteDeLíneaToolStripMenuItem
        ' 
        AjusteDeLíneaToolStripMenuItem.Name = "AjusteDeLíneaToolStripMenuItem"
        AjusteDeLíneaToolStripMenuItem.Size = New Size(197, 26)
        AjusteDeLíneaToolStripMenuItem.Text = "Ajuste de línea"
        ' 
        ' AyudaToolStripMenuItem
        ' 
        AyudaToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {VerLaAyudaToolStripMenuItem, EnviarComentariosToolStripMenuItem, AcercaDelBlocDeNotasToolStripMenuItem})
        AyudaToolStripMenuItem.Name = "AyudaToolStripMenuItem"
        AyudaToolStripMenuItem.Size = New Size(65, 24)
        AyudaToolStripMenuItem.Text = "Ay&uda"
        ' 
        ' VerLaAyudaToolStripMenuItem
        ' 
        VerLaAyudaToolStripMenuItem.Name = "VerLaAyudaToolStripMenuItem"
        VerLaAyudaToolStripMenuItem.Size = New Size(256, 26)
        VerLaAyudaToolStripMenuItem.Text = "Ver la Ayuda"
        ' 
        ' EnviarComentariosToolStripMenuItem
        ' 
        EnviarComentariosToolStripMenuItem.Name = "EnviarComentariosToolStripMenuItem"
        EnviarComentariosToolStripMenuItem.Size = New Size(256, 26)
        EnviarComentariosToolStripMenuItem.Text = "Enviar comentarios"
        ' 
        ' AcercaDelBlocDeNotasToolStripMenuItem
        ' 
        AcercaDelBlocDeNotasToolStripMenuItem.Name = "AcercaDelBlocDeNotasToolStripMenuItem"
        AcercaDelBlocDeNotasToolStripMenuItem.Size = New Size(256, 26)
        AcercaDelBlocDeNotasToolStripMenuItem.Text = "Acerca del Bloc de notas"
        ' 
        ' BúsquedaConBingToolStripMenuItem
        ' 
        BúsquedaConBingToolStripMenuItem.Name = "BúsquedaConBingToolStripMenuItem"
        BúsquedaConBingToolStripMenuItem.Size = New Size(228, 26)
        BúsquedaConBingToolStripMenuItem.Text = "Búsqueda con Bing..."
        ' 
        ' BuscarAnteriorToolStripMenuItem
        ' 
        BuscarAnteriorToolStripMenuItem.Name = "BuscarAnteriorToolStripMenuItem"
        BuscarAnteriorToolStripMenuItem.Size = New Size(228, 26)
        BuscarAnteriorToolStripMenuItem.Text = "Buscar anterior"
        ' 
        ' FormatoToolStripMenuItem
        ' 
        FormatoToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {AjusteDeLíneaToolStripMenuItem1, FuenteToolStripMenuItem1})
        FormatoToolStripMenuItem.Name = "FormatoToolStripMenuItem"
        FormatoToolStripMenuItem.Size = New Size(79, 24)
        FormatoToolStripMenuItem.Text = "F&ormato"
        ' 
        ' AjusteDeLíneaToolStripMenuItem1
        ' 
        AjusteDeLíneaToolStripMenuItem1.Name = "AjusteDeLíneaToolStripMenuItem1"
        AjusteDeLíneaToolStripMenuItem1.Size = New Size(224, 26)
        AjusteDeLíneaToolStripMenuItem1.Text = "Ajuste de línea"
        ' 
        ' FuenteToolStripMenuItem1
        ' 
        FuenteToolStripMenuItem1.Name = "FuenteToolStripMenuItem1"
        FuenteToolStripMenuItem1.Size = New Size(224, 26)
        FuenteToolStripMenuItem1.Text = "Fuente..."
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(MenuStrip1)
        MainMenuStrip = MenuStrip1
        Name = "Form1"
        Text = "Form1"
        MenuStrip1.ResumeLayout(False)
        MenuStrip1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ArchivoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NuevoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NuevaVentanaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AbrirToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GuardarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GuardarToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents EdiciónToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AyudaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DeshacerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CortarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CopiarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PegarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EliminarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ZoomToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AcercarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AlejarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RestaurarZoomPredeterminadoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BarraDeEstadoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AjusteDeLíneaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ConfiguraciónDePaginaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ImprimirToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalirToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BuscarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BuscarSiguienteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReemplazarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents IrAToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SeleccionarTodoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FuenteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VerLaAyudaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EnviarComentariosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AcercaDelBlocDeNotasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BúsquedaConBingToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BuscarAnteriorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FormatoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AjusteDeLíneaToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents FuenteToolStripMenuItem1 As ToolStripMenuItem

End Class
